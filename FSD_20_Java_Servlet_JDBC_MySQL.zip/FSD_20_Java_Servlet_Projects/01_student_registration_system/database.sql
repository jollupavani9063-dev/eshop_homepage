CREATE DATABASE IF NOT EXISTS fsd_lab;
USE fsd_lab;

CREATE TABLE IF NOT EXISTS students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id VARCHAR(500),
    student_name VARCHAR(500),
    email VARCHAR(500),
    department VARCHAR(500),
    year_of_study DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verify records after submitting the form:
SELECT * FROM students;
