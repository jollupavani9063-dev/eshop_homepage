const form=document.getElementById('form');const rows=document.getElementById('rows');const message=document.getElementById('message');let editingId=null;
const cfg=window.APP_CONFIG;
function val(r,k){return r[k]===null||r[k]===undefined?'':r[k]}
function cell(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
async function loadRecords(q=''){const res=await fetch('records'+(q?'?q='+encodeURIComponent(q):''));const data=await res.json();rows.innerHTML='';data.forEach(r=>{const tr=document.createElement('tr');let html='<td>'+r.id+'</td>';cfg.fields.forEach(f=>html+='<td>'+cell(val(r,f.name))+'</td>');
html+='<td><button class="small edit" onclick="editRecord('+r.id+')">Edit</button><button class="small delete" onclick="deleteRecord('+r.id+')">Delete</button>';
html+='</td>';tr.innerHTML=html;rows.appendChild(tr);});}
form.addEventListener('submit',async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(form).entries());data.action=editingId?'update':'create';if(editingId)data.id=editingId;const res=await fetch('records',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const out=await res.json();message.textContent=out.message||out.error; if(out.success){form.reset();editingId=null;document.getElementById('saveBtn').textContent='Save Record';loadRecords();}});
window.editRecord=async id=>{const res=await fetch('records');const data=await res.json();const r=data.find(x=>Number(x.id)===Number(id));if(!r)return;cfg.fields.forEach(f=>{if(form.elements[f.name])form.elements[f.name].value=val(r,f.name)});editingId=id;document.getElementById('saveBtn').textContent='Update Record';window.scrollTo({top:0,behavior:'smooth'});};
window.deleteRecord=async id=>{if(!confirm('Delete this record?'))return;const res=await fetch('records',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'delete',id})});const out=await res.json();message.textContent=out.message||out.error;loadRecords();};
window.markReturned=async id=>{await customAction(id,{return_status:'Returned'});};
window.nextStatus=async(id,current)=>{const next=current==='Pending'?'In Progress':current==='In Progress'?'Resolved':'Pending';await customAction(id,{status:next});};
async function customAction(id,extra){const res=await fetch('records');const all=await res.json();const r=all.find(x=>Number(x.id)===Number(id));if(!r)return;const payload={...r,...extra,action:'update',id};const out=await fetch('records',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});const result=await out.json();message.textContent=result.message||result.error;loadRecords();}
document.getElementById('clearBtn').addEventListener('click',()=>{form.reset();editingId=null;document.getElementById('saveBtn').textContent='Save Record';message.textContent='';});
loadRecords();
