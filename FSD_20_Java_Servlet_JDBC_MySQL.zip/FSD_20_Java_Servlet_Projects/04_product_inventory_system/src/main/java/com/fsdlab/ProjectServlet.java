package com.fsdlab;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

@WebServlet("/records")
public class ProjectServlet extends HttpServlet {
    private static final String URL = "jdbc:mysql://localhost:3306/fsd_lab?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "YOUR_MYSQL_PASSWORD";
    private static final String TABLE = "products";
    private static class Field {
        String name, label, type;
        Field(String n,String l,String t){name=n;label=l;type=t;}
    }
    private static final Field[] FIELDS = {
        new Field("product_code", "Product ID", "text"),
        new Field("product_name", "Product Name", "text"),
        new Field("category", "Category", "text"),
        new Field("price", "Price", "number"),
        new Field("quantity", "Quantity", "number")
    };
    private Connection getConnection() throws SQLException {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }
        catch (ClassNotFoundException e) { throw new SQLException("MySQL JDBC Driver not found",e); }
        return DriverManager.getConnection(URL,USER,PASSWORD);
    }
    private void json(HttpServletResponse response, String body) throws IOException {
        response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write(body);
    }
    private String esc(String s) {
        if(s==null)return "";
        return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r");
    }
    private String value(ResultSet rs,String col) throws SQLException {
        Object o=rs.getObject(col);
        if(o==null)return "null";
        if(o instanceof Number)return o.toString();
        return "\"" + esc(o.toString()) + "\"";
    }
    protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException {
        String q=req.getParameter("q");
        StringBuilder sql=new StringBuilder("SELECT * FROM "+TABLE);
        List<String> searchable=new ArrayList<>();
        for(Field f:FIELDS) if(f.type.equals("text")||f.type.equals("email")||f.type.equals("tel")) searchable.add(f.name);
        if(q!=null&&!q.trim().isEmpty()&&!searchable.isEmpty()) {
            sql.append(" WHERE ");
            for(int i=0;i<searchable.size();i++){if(i>0)sql.append(" OR ");sql.append(searchable.get(i)).append(" LIKE ?");}
        }
        sql.append(" ORDER BY id DESC");
        try(Connection c=getConnection();PreparedStatement ps=c.prepareStatement(sql.toString())) {
            if(q!=null&&!q.trim().isEmpty()&&!searchable.isEmpty()) for(int i=0;i<searchable.size();i++)ps.setString(i+1,"%"+q.trim()+"%");
            try(ResultSet rs=ps.executeQuery()) {
                StringBuilder out=new StringBuilder("[");boolean first=true;
                while(rs.next()) {
                    if(!first)out.append(",");first=false;
                    out.append("{\"id\":").append(rs.getLong("id"));
                    for(Field f:FIELDS)out.append(",\"").append(f.name).append("\":").append(value(rs,f.name));
                    out.append("}");
                }
                out.append("]");json(resp,out.toString());
            }
        } catch(SQLException e) { resp.setStatus(500);json(resp,"{\"error\":\""+esc(e.getMessage())+"\"}"); }
    }
    protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException {
        resp.setContentType("application/json;charset=UTF-8");
        Map<String,String> data=new HashMap<>();
        try(BufferedReader br=req.getReader()) {
            StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null)sb.append(line);
            String body=sb.toString();
            java.util.regex.Matcher m=java.util.regex.Pattern.compile("\\\"([^\\\"]+)\\\"\\s*:\\s*(?:\\\"((?:\\\\.|[^\\\"])*)\\\"|([^,}]+))").matcher(body);
            while(m.find())data.put(m.group(1),m.group(2)!=null?m.group(2):m.group(3).trim());
        }
        String action=data.get("action");
        try(Connection c=getConnection()) {
            if("delete".equals(action)) {
                try(PreparedStatement ps=c.prepareStatement("DELETE FROM "+TABLE+" WHERE id=?")){ps.setLong(1,Long.parseLong(data.get("id")));int n=ps.executeUpdate();json(resp,"{\"success\":true,\"message\":\"Record deleted\"}");}
                return;
            }
            if("update".equals(action)) {
                StringBuilder sql=new StringBuilder("UPDATE "+TABLE+" SET ");int i=0;
                for(Field f:FIELDS){if(i++>0)sql.append(",");sql.append(f.name).append("=?");}
                sql.append(" WHERE id=?");
                try(PreparedStatement ps=c.prepareStatement(sql.toString())) {
                    int idx=1;for(Field f:FIELDS)setValue(ps,idx++,f,data.get(f.name));
                    ps.setLong(idx,Long.parseLong(data.get("id")));ps.executeUpdate();
                }
                json(resp,"{\"success\":true,\"message\":\"Record updated\"}");return;
            }
            if("create".equals(action)) {
                StringBuilder cols=new StringBuilder(),marks=new StringBuilder();
                for(int i=0;i<FIELDS.length;i++){if(i>0){cols.append(",");marks.append(",");}cols.append(FIELDS[i].name);marks.append("?");}
                String sql="INSERT INTO "+TABLE+" ("+cols+") VALUES ("+marks+")";
                try(PreparedStatement ps=c.prepareStatement(sql)){int idx=1;for(Field f:FIELDS)setValue(ps,idx++,f,data.get(f.name));ps.executeUpdate();}
                json(resp,"{\"success\":true,\"message\":\"Record saved to MySQL\"}");return;
            }
            resp.setStatus(400);json(resp,"{\"success\":false,\"error\":\"Unknown action\"}");
        } catch(Exception e) {resp.setStatus(500);json(resp,"{\"success\":false,\"error\":\""+esc(e.getMessage())+"\"}");}
    }
    private void setValue(PreparedStatement ps,int index,Field f,String v)throws SQLException {
        if(v==null||v.isBlank()){ps.setNull(index,Types.NULL);return;}
        if(f.type.equals("number"))ps.setBigDecimal(index,new BigDecimal(v));
        else if(f.type.equals("date"))ps.setDate(index,java.sql.Date.valueOf(v));
        else ps.setString(index,v);
    }
}
