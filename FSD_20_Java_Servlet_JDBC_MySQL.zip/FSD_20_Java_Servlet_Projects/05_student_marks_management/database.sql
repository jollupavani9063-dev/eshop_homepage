CREATE DATABASE IF NOT EXISTS fsd_lab;
USE fsd_lab;

CREATE TABLE IF NOT EXISTS student_marks (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_code VARCHAR(500),
    student_name VARCHAR(500),
    subject_name VARCHAR(500),
    internal_marks DECIMAL(12,2),
    external_marks DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verify records after submitting the form:
SELECT * FROM student_marks;
