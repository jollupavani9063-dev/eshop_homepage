CREATE DATABASE IF NOT EXISTS fsd_lab;
USE fsd_lab;

CREATE TABLE IF NOT EXISTS contacts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    contact_name VARCHAR(500),
    phone_number VARCHAR(500),
    email_address VARCHAR(500),
    address VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verify records after submitting the form:
SELECT * FROM contacts;
