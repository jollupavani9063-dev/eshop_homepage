CREATE DATABASE IF NOT EXISTS fsd_lab;
USE fsd_lab;

CREATE TABLE IF NOT EXISTS book_issues (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id VARCHAR(500),
    student_name VARCHAR(500),
    book_id VARCHAR(500),
    book_name VARCHAR(500),
    issue_date DATE,
    return_status VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verify records after submitting the form:
SELECT * FROM book_issues;
