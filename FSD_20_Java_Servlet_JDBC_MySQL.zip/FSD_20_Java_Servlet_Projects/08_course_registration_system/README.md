# 8. Course Registration System

## Features
Register students for courses; edit, delete and display registrations.

## Technologies
HTML5, CSS3, JavaScript, Java Servlet (Jakarta), JDBC, MySQL 8, Maven, Tomcat 10.1.

## 1. Create the database
Open MySQL Workbench, open `database.sql`, and execute the complete script. It creates the `fsd_lab` database and the `course_registrations` table.

## 2. Configure the MySQL password
Open `src/main/java/com/fsdlab/ProjectServlet.java` and change:
`private static final String PASSWORD = "YOUR_MYSQL_PASSWORD";`
to your local MySQL root password. If your MySQL root account has no password, use an empty string.

## 3. Open and run
1. Open NetBeans.
2. Choose File → Open Project and select this project's folder (the folder containing `pom.xml`).
3. Make sure JDK 17+ and Apache Tomcat 10.1 are configured in NetBeans.
4. Right-click the project → Clean and Build.
5. Run on Tomcat 10.1.
6. Open `http://localhost:8080/FSDProject/` (your port may differ).

## 4. Demonstrate database connectivity to ma'am
1. Add a record in the webpage and click Save Record.
2. Confirm that it appears in the Saved Records table.
3. Open MySQL Workbench and run `USE fsd_lab; SELECT * FROM course_registrations;`.
4. Show the same record in MySQL Workbench. This demonstrates that the Servlet saved it in MySQL through JDBC.
5. Try Edit and Delete and refresh the page to show the changes.

## Project files
- `src/main/webapp/index.html` — frontend page
- `src/main/webapp/style.css` — styling
- `src/main/webapp/config.js` — field configuration
- `src/main/webapp/app.js` — browser-side form and table logic
- `src/main/java/com/fsdlab/ProjectServlet.java` — Servlet + JDBC backend
- `database.sql` — database and table creation
- `pom.xml` — Maven dependencies

## Notes
- The Servlet endpoint is `/records`.
- The app uses prepared statements for database operations.
- This is a lab/demo implementation. Do not use it with public internet access or real personal data without adding authentication, authorization, CSRF protection, stronger validation and production configuration.
