CREATE DATABASE IF NOT EXISTS fsd_lab;
USE fsd_lab;

CREATE TABLE IF NOT EXISTS employee_salaries (
    id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id VARCHAR(500),
    employee_name VARCHAR(500),
    basic_salary DECIMAL(12,2),
    allowance DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verify records after submitting the form:
SELECT * FROM employee_salaries;
