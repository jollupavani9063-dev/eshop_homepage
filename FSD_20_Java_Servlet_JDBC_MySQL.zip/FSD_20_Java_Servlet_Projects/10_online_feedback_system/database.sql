CREATE DATABASE IF NOT EXISTS fsd_lab;
USE fsd_lab;

CREATE TABLE IF NOT EXISTS feedback (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_name VARCHAR(500),
    course_name VARCHAR(500),
    rating DECIMAL(12,2),
    comments VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verify records after submitting the form:
SELECT * FROM feedback;
