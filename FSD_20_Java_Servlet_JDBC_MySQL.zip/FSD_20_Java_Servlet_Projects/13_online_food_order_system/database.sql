CREATE DATABASE IF NOT EXISTS fsd_lab;
USE fsd_lab;

CREATE TABLE IF NOT EXISTS food_orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(500),
    phone_number VARCHAR(500),
    address VARCHAR(500),
    food_item VARCHAR(500),
    quantity DECIMAL(12,2),
    unit_price DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verify records after submitting the form:
SELECT * FROM food_orders;
