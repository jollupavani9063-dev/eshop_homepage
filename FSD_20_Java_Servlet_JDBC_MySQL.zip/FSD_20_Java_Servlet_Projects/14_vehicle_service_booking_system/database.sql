CREATE DATABASE IF NOT EXISTS fsd_lab;
USE fsd_lab;

CREATE TABLE IF NOT EXISTS service_bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(500),
    vehicle_number VARCHAR(500),
    vehicle_type VARCHAR(500),
    service_type VARCHAR(500),
    service_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verify records after submitting the form:
SELECT * FROM service_bookings;
