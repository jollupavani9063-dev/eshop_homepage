CREATE DATABASE IF NOT EXISTS fsd_lab;
USE fsd_lab;

CREATE TABLE IF NOT EXISTS job_applications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    candidate_name VARCHAR(500),
    email VARCHAR(500),
    phone_number VARCHAR(500),
    qualification VARCHAR(500),
    position_applied VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verify records after submitting the form:
SELECT * FROM job_applications;
