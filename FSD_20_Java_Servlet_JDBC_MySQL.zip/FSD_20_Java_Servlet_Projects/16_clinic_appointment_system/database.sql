CREATE DATABASE IF NOT EXISTS fsd_lab;
USE fsd_lab;

CREATE TABLE IF NOT EXISTS appointments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_name VARCHAR(500),
    phone_number VARCHAR(500),
    doctor VARCHAR(500),
    appointment_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verify records after submitting the form:
SELECT * FROM appointments;
