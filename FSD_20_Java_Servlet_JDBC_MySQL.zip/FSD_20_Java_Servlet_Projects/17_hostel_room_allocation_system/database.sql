CREATE DATABASE IF NOT EXISTS fsd_lab;
USE fsd_lab;

CREATE TABLE IF NOT EXISTS hostel_allocations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id VARCHAR(500),
    student_name VARCHAR(500),
    room_number VARCHAR(500),
    block_name VARCHAR(500),
    room_capacity DECIMAL(12,2),
    available_beds DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verify records after submitting the form:
SELECT * FROM hostel_allocations;
