CREATE DATABASE IF NOT EXISTS fsd_lab;
USE fsd_lab;

CREATE TABLE IF NOT EXISTS movie_bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(500),
    phone_number VARCHAR(500),
    movie_name VARCHAR(500),
    language VARCHAR(500),
    ticket_price DECIMAL(12,2),
    ticket_count DECIMAL(12,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Verify records after submitting the form:
SELECT * FROM movie_bookings;
