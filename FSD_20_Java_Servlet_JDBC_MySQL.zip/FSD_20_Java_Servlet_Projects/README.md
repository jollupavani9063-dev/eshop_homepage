# FSD Lab — 20 Java Servlet + JDBC + MySQL Projects

All 20 projects are separate Maven WAR applications. Each project includes its own frontend, Servlet backend, JDBC connection, SQL script and run instructions.

## Shared setup
1. Install JDK 17 or later, NetBeans, Apache Tomcat 10.1, Maven support and MySQL 8.
2. In MySQL Workbench execute the selected project's `database.sql`.
3. Set your MySQL password in that project's `ProjectServlet.java`.
4. Open the project folder in NetBeans, Clean and Build, then Run on Tomcat.
5. Visit `http://localhost:8080/FSDProject/` (adjust host/port/context path if NetBeans deploys differently).
6. Verify persistence in MySQL Workbench using the SELECT query in that project's README.

## Project list
1. [Student Registration System](01_student_registration_system/README.md) — table `students`
2. [Employee Leave Application](02_employee_leave_application/README.md) — table `leave_applications`
3. [Book Management System](03_book_management_system/README.md) — table `books`
4. [Product Inventory System](04_product_inventory_system/README.md) — table `products`
5. [Student Marks Management](05_student_marks_management/README.md) — table `student_marks`
6. [Contact Management System](06_contact_management_system/README.md) — table `contacts`
7. [Library Book Issue System](07_library_book_issue_system/README.md) — table `book_issues`
8. [Course Registration System](08_course_registration_system/README.md) — table `course_registrations`
9. [Employee Salary Management](09_employee_salary_management/README.md) — table `employee_salaries`
10. [Online Feedback System](10_online_feedback_system/README.md) — table `feedback`
11. [Event Registration System](11_event_registration_system/README.md) — table `event_registrations`
12. [Simple Expense Tracker](12_simple_expense_tracker/README.md) — table `expenses`
13. [Online Food Order System](13_online_food_order_system/README.md) — table `food_orders`
14. [Vehicle Service Booking System](14_vehicle_service_booking_system/README.md) — table `service_bookings`
15. [Job Application Portal](15_job_application_portal/README.md) — table `job_applications`
16. [Clinic Appointment System](16_clinic_appointment_system/README.md) — table `appointments`
17. [Hostel Room Allocation System](17_hostel_room_allocation_system/README.md) — table `hostel_allocations`
18. [Movie Ticket Booking System](18_movie_ticket_booking_system/README.md) — table `movie_bookings`
19. [Complaint Management System](19_complaint_management_system/README.md) — table `complaints`
20. [Student Attendance Management](20_student_attendance_management/README.md) — table `attendance_records`

## Important compatibility note
The supplied question bank lists React and Spring Boot for several questions. These 20 implementations intentionally use the single requested stack: HTML/CSS/JavaScript + Java Servlet + JDBC + MySQL. Confirm with your instructor that this stack is accepted for your assigned question.

## Database connection
Every project uses the same local database name `fsd_lab`, but each has a different table. The JDBC URL is `jdbc:mysql://localhost:3306/fsd_lab?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC`. Change the root password in the servlet before running.